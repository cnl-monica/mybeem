#!/bin/sh

#
# 1.5.1    r8171    06/09/2014
#
autoreconf -ivf
./configure
